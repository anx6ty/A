\
import discord
from discord import app_commands
from discord.ext import commands
from ..core.embeds import ok

class Owner(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def check(self, interaction):
        if interaction.user.id != self.bot.owner_id:
            raise app_commands.CheckFailure("Bot owner only.")

    @app_commands.command(name="shutdown", description="Owner-only shutdown.")
    async def shutdown(self, interaction):
        await self.check(interaction)
        await interaction.response.send_message(embed=ok("Shutdown", "Shutting down."), ephemeral=True)
        await self.bot.close()

async def setup(bot):
    await bot.add_cog(Owner(bot))
