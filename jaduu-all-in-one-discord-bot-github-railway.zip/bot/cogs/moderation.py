\
from datetime import datetime, timezone, timedelta
import discord
from discord import app_commands
from discord.ext import commands
from ..core.checks import mod
from ..core.embeds import ok, error
from ..core.logging import send_log

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def case(self, guild, kind, target, moderator, reason):
        cid = await self.bot.db.add_case(
            guild.id, kind, target.id, moderator.id, reason,
            datetime.now(timezone.utc).isoformat()
        )
        cfg = await self.bot.db.guild(guild.id)
        await send_log(
            guild,
            cfg["mod_log_channel_id"] or cfg["log_channel_id"],
            f"Case #{cid} — {kind}",
            f"**Target:** {target.mention if hasattr(target,'mention') else target}\n"
            f"**Moderator:** {moderator.mention}\n**Reason:** {reason}"
        )
        return cid

    async def guard(self, interaction, target):
        bot_member = interaction.guild.me
        if not bot_member or not isinstance(interaction.user, discord.Member):
            await interaction.response.send_message(embed=error("Error", "Unable to validate hierarchy."), ephemeral=True)
            return False
        if target == interaction.guild.owner or target.top_role >= bot_member.top_role or (
            interaction.user.id != interaction.guild.owner_id and target.top_role >= interaction.user.top_role
        ):
            await interaction.response.send_message(
                embed=error("Hierarchy", "Discord's role hierarchy prevents this action."),
                ephemeral=True
            )
            return False
        return True

    @app_commands.command(name="ban", description="Ban a member.")
    @app_commands.describe(member="Member", reason="Reason")
    @mod()
    async def ban(self, interaction, member: discord.Member, reason: str = "No reason provided"):
        if not await self.guard(interaction, member): return
        try:
            await member.send(embed=error("You were banned", f"From **{interaction.guild.name}**.\nReason: {reason}"))
        except discord.HTTPException:
            pass
        await member.ban(reason=reason, delete_message_seconds=0)
        cid = await self.case(interaction.guild, "Ban", member, interaction.user, reason)
        await interaction.response.send_message(embed=ok("Banned", f"{member} was banned. Case **#{cid}**."))

    @app_commands.command(name="unban", description="Unban a user by ID.")
    @mod()
    async def unban(self, interaction, user_id: str, reason: str = "No reason provided"):
        try:
            user = await self.bot.fetch_user(int(user_id))
            await interaction.guild.unban(user, reason=reason)
            cid = await self.bot.db.add_case(interaction.guild.id, "Unban", user.id, interaction.user.id, reason, datetime.now(timezone.utc).isoformat())
            await interaction.response.send_message(embed=ok("Unbanned", f"{user} was unbanned. Case **#{cid}**."))
        except (ValueError, discord.NotFound, discord.Forbidden):
            await interaction.response.send_message(embed=error("Unban failed", "Invalid ID, user not banned, or permission denied."), ephemeral=True)

    @app_commands.command(name="kick", description="Kick a member.")
    @mod()
    async def kick(self, interaction, member: discord.Member, reason: str = "No reason provided"):
        if not await self.guard(interaction, member): return
        await member.kick(reason=reason)
        cid = await self.case(interaction.guild, "Kick", member, interaction.user, reason)
        await interaction.response.send_message(embed=ok("Kicked", f"{member} was kicked. Case **#{cid}**."))

    @app_commands.command(name="softban", description="Ban and immediately unban a member.")
    @mod()
    async def softban(self, interaction, member: discord.Member, reason: str = "No reason provided"):
        if not await self.guard(interaction, member): return
        await member.ban(reason=reason, delete_message_seconds=86400)
        await interaction.guild.unban(member, reason="Softban release")
        cid = await self.case(interaction.guild, "Softban", member, interaction.user, reason)
        await interaction.response.send_message(embed=ok("Softbanned", f"{member} was softbanned. Case **#{cid}**."))

    @app_commands.command(name="timeout", description="Timeout a member.")
    @mod()
    async def timeout(self, interaction, member: discord.Member, duration_minutes: app_commands.Range[int,1,40320], reason: str = "No reason provided"):
        if not await self.guard(interaction, member): return
        await member.timeout(timedelta(minutes=duration_minutes), reason=reason)
        cid = await self.case(interaction.guild, "Timeout", member, interaction.user, reason)
        await interaction.response.send_message(embed=ok("Timed out", f"{member.mention} for **{duration_minutes}m**. Case **#{cid}**."))

    @app_commands.command(name="untimeout", description="Remove a timeout.")
    @mod()
    async def untimeout(self, interaction, member: discord.Member, reason: str = "No reason provided"):
        if not await self.guard(interaction, member): return
        await member.timeout(None, reason=reason)
        cid = await self.case(interaction.guild, "Untimeout", member, interaction.user, reason)
        await interaction.response.send_message(embed=ok("Timeout removed", f"{member.mention}. Case **#{cid}**."))

    @app_commands.command(name="warn", description="Warn a member.")
    @mod()
    async def warn(self, interaction, member: discord.Member, reason: str = "No reason provided"):
        await self.bot.db.execute(
            "INSERT INTO warnings(guild_id,user_id,moderator_id,reason,created_at) VALUES(?,?,?,?,?)",
            (interaction.guild.id, member.id, interaction.user.id, reason, datetime.now(timezone.utc).isoformat())
        )
        cid = await self.case(interaction.guild, "Warn", member, interaction.user, reason)
        try:
            await member.send(embed=error("Warning", f"You were warned in **{interaction.guild.name}**.\nReason: {reason}"))
        except discord.HTTPException:
            pass
        await interaction.response.send_message(embed=ok("Warned", f"{member.mention} was warned. Case **#{cid}**."))

    @app_commands.command(name="warnings", description="View warnings.")
    @mod()
    async def warnings(self, interaction, member: discord.Member):
        rows = await self.bot.db.fetchall(
            "SELECT * FROM warnings WHERE guild_id=? AND user_id=? ORDER BY id DESC",
            (interaction.guild.id, member.id)
        )
        if not rows:
            return await interaction.response.send_message(embed=ok("Warnings", "No warnings found."))
        text = "\n".join(f"**#{r['id']}** — {r['reason']}" for r in rows[:15])
        await interaction.response.send_message(embed=ok(f"Warnings — {member}", text))

    @app_commands.command(name="clearwarnings", description="Clear all warnings.")
    @mod()
    async def clearwarnings(self, interaction, member: discord.Member):
        await self.bot.db.execute("DELETE FROM warnings WHERE guild_id=? AND user_id=?", (interaction.guild.id, member.id))
        await interaction.response.send_message(embed=ok("Warnings cleared", f"Cleared warnings for {member.mention}."))

    @app_commands.command(name="purge", description="Delete recent messages.")
    @mod()
    async def purge(self, interaction, amount: app_commands.Range[int,1,100]):
        await interaction.response.defer(ephemeral=True)
        deleted = await interaction.channel.purge(limit=amount)
        await interaction.followup.send(embed=ok("Purged", f"Deleted **{len(deleted)}** messages."), ephemeral=True)

    @app_commands.command(name="slowmode", description="Set channel slowmode.")
    @mod()
    async def slowmode(self, interaction, seconds: app_commands.Range[int,0,21600]):
        await interaction.channel.edit(slowmode_delay=seconds, reason=f"By {interaction.user}")
        await interaction.response.send_message(embed=ok("Slowmode", f"Set to **{seconds}s**."))

    async def set_lock(self, channel, locked):
        ow = channel.overwrites_for(channel.guild.default_role)
        ow.send_messages = False if locked else None
        await channel.set_permissions(channel.guild.default_role, overwrite=ow)

    @app_commands.command(name="lock", description="Lock this channel.")
    @mod()
    async def lock(self, interaction):
        await self.set_lock(interaction.channel, True)
        await interaction.response.send_message(embed=ok("Locked", "Channel locked."))

    @app_commands.command(name="unlock", description="Unlock this channel.")
    @mod()
    async def unlock(self, interaction):
        await self.set_lock(interaction.channel, False)
        await interaction.response.send_message(embed=ok("Unlocked", "Channel unlocked."))

    @app_commands.command(name="hide", description="Hide this channel.")
    @mod()
    async def hide(self, interaction):
        await interaction.channel.set_permissions(interaction.guild.default_role, view_channel=False)
        await interaction.response.send_message(embed=ok("Hidden", "Channel hidden from @everyone."))

    @app_commands.command(name="unhide", description="Show this channel.")
    @mod()
    async def unhide(self, interaction):
        await interaction.channel.set_permissions(interaction.guild.default_role, view_channel=None)
        await interaction.response.send_message(embed=ok("Visible", "Channel is visible again."))

async def setup(bot):
    await bot.add_cog(Moderation(bot))
