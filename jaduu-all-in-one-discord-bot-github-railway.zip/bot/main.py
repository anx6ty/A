\
from __future__ import annotations
import asyncio
import logging
import discord
from discord.ext import commands
from .config import load_settings
from .database.db import Database
from .core.logging import log, send_log

EXTENSIONS = [
    "bot.cogs.config",
    "bot.cogs.moderation",
    "bot.cogs.antinuke",
    "bot.cogs.automod",
    "bot.cogs.voice",
    "bot.cogs.utility",
    "bot.cogs.community",
    "bot.cogs.owner",
]

class JaduuBot(commands.Bot):
    def __init__(self, settings):
        intents = discord.Intents.default()
        intents.guilds = True
        intents.members = True
        intents.message_content = True
        intents.messages = True
        intents.voice_states = True
        super().__init__(
            command_prefix=self.get_prefix_dynamic,
            intents=intents,
            help_command=None,
            allowed_mentions=discord.AllowedMentions(everyone=False, roles=False, users=True),
        )
        self.settings = settings
        self.owner_id = settings.owner_id
        self.db = Database(settings.database_path)
        self.started_at = discord.utils.utcnow()

    async def get_prefix_dynamic(self, bot, message):
        if not message.guild:
            return self.settings.prefix
        cfg = await self.db.guild(message.guild.id)
        return cfg["prefix"] or self.settings.prefix

    async def setup_hook(self):
        await self.db.connect()
        for extension in EXTENSIONS:
            try:
                await self.load_extension(extension)
                log.info("Loaded %s", extension)
            except Exception:
                log.exception("Failed to load %s", extension)
        await self.tree.sync()

    async def security_log(self, guild, text):
        cfg = await self.db.guild(guild.id)
        await send_log(
            guild,
            cfg["security_log_channel_id"] or cfg["log_channel_id"],
            "Security",
            text,
            discord.Color.orange(),
        )

    async def on_ready(self):
        log.info("Logged in as %s (%s) | %s guilds", self.user, self.user.id, len(self.guilds))
        await self.change_presence(activity=discord.Game(name="/help • /config"))

    async def close(self):
        await self.db.close()
        await super().close()

    async def on_app_command_error(self, interaction, error):
        log.exception("Slash command error", exc_info=error)
        if isinstance(error, discord.app_commands.CheckFailure):
            message = str(error) or "You do not have permission to use this command."
        elif isinstance(error, discord.Forbidden):
            message = "Discord denied this action. Check permissions and role hierarchy."
        elif isinstance(error, discord.NotFound):
            message = "That Discord resource no longer exists."
        else:
            message = "An unexpected error occurred. Staff have been notified."
        try:
            if interaction.response.is_done():
                await interaction.followup.send(message, ephemeral=True)
            else:
                await interaction.response.send_message(message, ephemeral=True)
        except discord.HTTPException:
            pass

async def runner():
    settings = load_settings()
    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )
    bot = JaduuBot(settings)
    async with bot:
        await bot.start(settings.token)

def main():
    try:
        asyncio.run(runner())
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    main()
