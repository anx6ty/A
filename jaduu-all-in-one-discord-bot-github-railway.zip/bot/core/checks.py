import discord
from discord import app_commands

def admin():
    async def predicate(interaction: discord.Interaction):
        if not interaction.guild or not isinstance(interaction.user, discord.Member):
            raise app_commands.CheckFailure("This command can only be used in a server.")
        if interaction.user.id == interaction.guild.owner_id or interaction.user.guild_permissions.administrator:
            return True
        raise app_commands.CheckFailure("Administrator permission is required.")
    return app_commands.check(predicate)

def mod():
    async def predicate(interaction: discord.Interaction):
        if not interaction.guild or not isinstance(interaction.user, discord.Member):
            raise app_commands.CheckFailure("This command can only be used in a server.")
        p = interaction.user.guild_permissions
        if interaction.user.id == interaction.guild.owner_id or p.manage_guild or p.moderate_members or p.kick_members or p.ban_members:
            return True
        raise app_commands.CheckFailure("You do not have moderation permissions.")
    return app_commands.check(predicate)
