\
import re
import discord
from discord import app_commands
from discord.ext import commands
from ..core.checks import admin
from ..core.embeds import ok, error

VAR = re.compile(r"\{(user|username|server|membercount|userid|mention)\}")

def render(text, member):
    values = {
        "user": str(member),
        "username": member.name,
        "server": member.guild.name,
        "membercount": str(member.guild.member_count),
        "userid": str(member.id),
        "mention": member.mention,
    }
    return VAR.sub(lambda m: values[m.group(1)], text)

class Community(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member):
        cfg = await self.bot.db.guild(member.guild.id)
        if cfg["autorole_id"]:
            role = member.guild.get_role(cfg["autorole_id"])
            if role:
                try: await member.add_roles(role, reason="Autorole")
                except discord.HTTPException: pass
        if cfg["welcome_channel_id"] and cfg["welcome_message"]:
            channel = member.guild.get_channel(cfg["welcome_channel_id"])
            if isinstance(channel, discord.TextChannel):
                try: await channel.send(render(cfg["welcome_message"], member))
                except discord.HTTPException: pass

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        cfg = await self.bot.db.guild(member.guild.id)
        if cfg["goodbye_channel_id"] and cfg["goodbye_message"]:
            channel = member.guild.get_channel(cfg["goodbye_channel_id"])
            if isinstance(channel, discord.TextChannel):
                try: await channel.send(render(cfg["goodbye_message"], member))
                except discord.HTTPException: pass

    @app_commands.command(name="verify", description="Verify yourself.")
    async def verify(self, interaction):
        cfg = await self.bot.db.guild(interaction.guild.id)
        role = interaction.guild.get_role(cfg["verified_role_id"]) if cfg["verified_role_id"] else None
        unverified = interaction.guild.get_role(cfg["unverified_role_id"]) if cfg["unverified_role_id"] else None
        if not role:
            return await interaction.response.send_message(
                embed=error("Verification", "Verification is not configured."),
                ephemeral=True
            )
        try:
            await interaction.user.add_roles(role)
            if unverified:
                await interaction.user.remove_roles(unverified)
            await interaction.response.send_message(embed=ok("Verified", "You are verified."), ephemeral=True)
        except discord.HTTPException:
            await interaction.response.send_message(embed=error("Verification", "I could not update your roles."), ephemeral=True)

    @app_commands.command(name="customcommand-create", description="Create a custom command.")
    @admin()
    async def custom_create(self, interaction, name: str, response: str):
        name = name.lower()
        await self.bot.db.execute(
            "INSERT OR REPLACE INTO custom_commands(guild_id,name,response) VALUES(?,?,?)",
            (interaction.guild.id, name, response)
        )
        await interaction.response.send_message(embed=ok("Custom command", f"Created `{name}`."), ephemeral=True)

    @app_commands.command(name="config-welcome", description="Set welcome channel and message.")
    @admin()
    async def config_welcome(self, interaction, channel: discord.TextChannel, message: str):
        await self.bot.db.set_guild(interaction.guild.id, welcome_channel_id=channel.id, welcome_message=message)
        await interaction.response.send_message(embed=ok("Welcome", "Saved."), ephemeral=True)

    @app_commands.command(name="config-goodbye", description="Set goodbye channel and message.")
    @admin()
    async def config_goodbye(self, interaction, channel: discord.TextChannel, message: str):
        await self.bot.db.set_guild(interaction.guild.id, goodbye_channel_id=channel.id, goodbye_message=message)
        await interaction.response.send_message(embed=ok("Goodbye", "Saved."), ephemeral=True)

async def setup(bot):
    await bot.add_cog(Community(bot))
