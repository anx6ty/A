import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass(frozen=True)
class Settings:
    token: str
    owner_id: int
    database_path: str
    prefix: str
    log_level: str

def load_settings() -> Settings:
    token = os.getenv("DISCORD_TOKEN", "").strip()
    if not token:
        raise RuntimeError("DISCORD_TOKEN is missing.")
    owner_id = int(os.getenv("BOT_OWNER_ID", "0"))
    if owner_id <= 0:
        raise RuntimeError("BOT_OWNER_ID must be set.")
    return Settings(
        token=token,
        owner_id=owner_id,
        database_path=os.getenv("DATABASE_PATH", "data/bot.sqlite3"),
        prefix=os.getenv("PREFIX", "!"),
        log_level=os.getenv("LOG_LEVEL", "INFO"),
    )
