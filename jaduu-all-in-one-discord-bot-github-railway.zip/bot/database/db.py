\
from __future__ import annotations
from pathlib import Path
import aiosqlite

SCHEMA = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS guild_config (
    guild_id INTEGER PRIMARY KEY,
    prefix TEXT NOT NULL DEFAULT '!',
    log_channel_id INTEGER,
    mod_log_channel_id INTEGER,
    security_log_channel_id INTEGER,
    welcome_channel_id INTEGER,
    goodbye_channel_id INTEGER,
    welcome_message TEXT,
    goodbye_message TEXT,
    autorole_id INTEGER,
    verified_role_id INTEGER,
    unverified_role_id INTEGER,
    jtc_channel_id INTEGER,
    jtc_category_id INTEGER,
    jtc_room_limit INTEGER DEFAULT 0,
    antinuke_enabled INTEGER DEFAULT 0,
    antinuke_threshold INTEGER DEFAULT 5,
    antinuke_window INTEGER DEFAULT 10,
    raid_mode INTEGER DEFAULT 0,
    automod_enabled INTEGER DEFAULT 0,
    automod_words TEXT DEFAULT '[]',
    automod_invites INTEGER DEFAULT 1,
    automod_mentions INTEGER DEFAULT 5,
    automod_caps INTEGER DEFAULT 85,
    automod_account_age INTEGER DEFAULT 0,
    automod_spam_count INTEGER DEFAULT 6,
    automod_spam_window INTEGER DEFAULT 8,
    config_json TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS cases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL,
    case_type TEXT NOT NULL,
    target_id INTEGER NOT NULL,
    moderator_id INTEGER NOT NULL,
    reason TEXT,
    created_at TEXT NOT NULL,
    evidence TEXT
);

CREATE TABLE IF NOT EXISTS warnings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    moderator_id INTEGER NOT NULL,
    reason TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS whitelist (
    guild_id INTEGER NOT NULL,
    subject_id INTEGER NOT NULL,
    subject_type TEXT NOT NULL,
    PRIMARY KEY (guild_id, subject_id, subject_type)
);

CREATE TABLE IF NOT EXISTS custom_commands (
    guild_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    response TEXT NOT NULL,
    PRIMARY KEY (guild_id, name)
);

CREATE TABLE IF NOT EXISTS levels (
    guild_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    xp INTEGER NOT NULL DEFAULT 0,
    level INTEGER NOT NULL DEFAULT 0,
    last_xp REAL NOT NULL DEFAULT 0,
    PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS jtc_rooms (
    guild_id INTEGER NOT NULL,
    channel_id INTEGER PRIMARY KEY,
    owner_id INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS automations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL,
    kind TEXT NOT NULL,
    payload TEXT NOT NULL,
    run_at TEXT
);
"""

class Database:
    def __init__(self, path: str):
        self.path = path
        self.conn: aiosqlite.Connection | None = None

    async def connect(self):
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = await aiosqlite.connect(self.path)
        self.conn.row_factory = aiosqlite.Row
        await self.conn.executescript(SCHEMA)
        await self.conn.commit()

    async def close(self):
        if self.conn:
            await self.conn.close()

    async def execute(self, sql, params=()):
        if not self.conn:
            raise RuntimeError("Database is not connected.")
        cur = await self.conn.execute(sql, params)
        await self.conn.commit()
        return cur

    async def fetchone(self, sql, params=()):
        if not self.conn:
            raise RuntimeError("Database is not connected.")
        cur = await self.conn.execute(sql, params)
        return await cur.fetchone()

    async def fetchall(self, sql, params=()):
        if not self.conn:
            raise RuntimeError("Database is not connected.")
        cur = await self.conn.execute(sql, params)
        return await cur.fetchall()

    async def guild(self, guild_id: int):
        row = await self.fetchone("SELECT * FROM guild_config WHERE guild_id=?", (guild_id,))
        if row:
            return row
        await self.execute("INSERT INTO guild_config(guild_id) VALUES (?)", (guild_id,))
        return await self.fetchone("SELECT * FROM guild_config WHERE guild_id=?", (guild_id,))

    async def set_guild(self, guild_id: int, **values):
        await self.guild(guild_id)
        if not values:
            return
        columns = ", ".join(f"{key}=?" for key in values)
        await self.execute(
            f"UPDATE guild_config SET {columns} WHERE guild_id=?",
            (*values.values(), guild_id),
        )

    async def add_case(self, guild_id, case_type, target_id, moderator_id, reason, created_at, evidence=None):
        cur = await self.execute(
            "INSERT INTO cases(guild_id,case_type,target_id,moderator_id,reason,created_at,evidence) VALUES(?,?,?,?,?,?,?)",
            (guild_id, case_type, target_id, moderator_id, reason, created_at, evidence),
        )
        return cur.lastrowid
