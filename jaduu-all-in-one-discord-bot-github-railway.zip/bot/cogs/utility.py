\
import discord
from discord import app_commands
from discord.ext import commands
from ..core.embeds import info

class Utility(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="ping", description="Show latency.")
    async def ping(self, interaction):
        await interaction.response.send_message(embed=info("Pong", f"`{round(self.bot.latency * 1000)}ms`"))

    @app_commands.command(name="uptime", description="Show uptime.")
    async def uptime(self, interaction):
        delta = discord.utils.utcnow() - self.bot.started_at
        await interaction.response.send_message(embed=info("Uptime", str(delta).split(".")[0]))

    @app_commands.command(name="userinfo", description="Show user information.")
    async def userinfo(self, interaction, member: discord.Member | None = None):
        member = member or interaction.user
        e = info("User Info", f"**User:** {member}\n**ID:** `{member.id}`\n**Created:** <t:{int(member.created_at.timestamp())}:F>")
        e.set_thumbnail(url=member.display_avatar.url)
        await interaction.response.send_message(embed=e)

    @app_commands.command(name="serverinfo", description="Show server information.")
    async def serverinfo(self, interaction):
        g = interaction.guild
        e = info("Server Info", f"**Name:** {g.name}\n**ID:** `{g.id}`\n**Owner:** <@{g.owner_id}>\n**Members:** {g.member_count}\n**Channels:** {len(g.channels)}\n**Roles:** {len(g.roles)}")
        if g.icon:
            e.set_thumbnail(url=g.icon.url)
        await interaction.response.send_message(embed=e)

    @app_commands.command(name="avatar", description="Show an avatar.")
    async def avatar(self, interaction, member: discord.Member | None = None):
        member = member or interaction.user
        e = info(f"{member}'s Avatar", "")
        e.set_image(url=member.display_avatar.url)
        await interaction.response.send_message(embed=e)

    @app_commands.command(name="botinfo", description="Show bot information.")
    async def botinfo(self, interaction):
        await interaction.response.send_message(embed=info("Jaduu", f"discord.py `{discord.__version__}` • Guilds: **{len(self.bot.guilds)}**"))

async def setup(bot):
    await bot.add_cog(Utility(bot))
