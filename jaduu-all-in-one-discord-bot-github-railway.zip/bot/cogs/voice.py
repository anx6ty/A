\
import discord
from discord import app_commands
from discord.ext import commands

class VoiceRooms(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        cfg = await self.bot.db.guild(member.guild.id)

        if before.channel:
            await self.cleanup(before.channel)

        if not after.channel or after.channel.id != cfg["jtc_channel_id"]:
            return

        category = member.guild.get_channel(cfg["jtc_category_id"]) if cfg["jtc_category_id"] else after.channel.category
        try:
            room = await member.guild.create_voice_channel(
                name=f"🎧・{member.display_name}",
                category=category,
                user_limit=cfg["jtc_room_limit"] or 0,
                reason="Join-to-create"
            )
            await self.bot.db.execute(
                "INSERT OR REPLACE INTO jtc_rooms(guild_id,channel_id,owner_id) VALUES(?,?,?)",
                (member.guild.id, room.id, member.id)
            )
            await member.move_to(room)
        except discord.HTTPException:
            pass

    async def cleanup(self, channel):
        row = await self.bot.db.fetchone("SELECT * FROM jtc_rooms WHERE channel_id=?", (channel.id,))
        if row and not channel.members:
            await self.bot.db.execute("DELETE FROM jtc_rooms WHERE channel_id=?", (channel.id,))
            try:
                await channel.delete(reason="Empty Join-to-create room")
            except discord.HTTPException:
                pass

    async def owner(self, interaction):
        row = await self.bot.db.fetchone("SELECT * FROM jtc_rooms WHERE channel_id=?", (interaction.channel.id,))
        if not row or row["owner_id"] != interaction.user.id:
            await interaction.response.send_message("You do not own this room.", ephemeral=True)
            return False
        return True

    @app_commands.command(name="vc-rename", description="Rename your room.")
    async def rename(self, interaction, name: str):
        if await self.owner(interaction):
            await interaction.channel.edit(name=name[:100])
            await interaction.response.send_message("Room renamed.", ephemeral=True)

    @app_commands.command(name="vc-limit", description="Set room limit.")
    async def limit(self, interaction, limit: app_commands.Range[int,0,99]):
        if await self.owner(interaction):
            await interaction.channel.edit(user_limit=limit)
            await interaction.response.send_message(f"Limit set to {limit}.", ephemeral=True)

    @app_commands.command(name="vc-lock", description="Lock your room.")
    async def lock(self, interaction):
        if await self.owner(interaction):
            await interaction.channel.set_permissions(interaction.guild.default_role, connect=False)
            await interaction.response.send_message("Room locked.", ephemeral=True)

    @app_commands.command(name="vc-unlock", description="Unlock your room.")
    async def unlock(self, interaction):
        if await self.owner(interaction):
            await interaction.channel.set_permissions(interaction.guild.default_role, connect=None)
            await interaction.response.send_message("Room unlocked.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(VoiceRooms(bot))
