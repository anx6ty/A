"""
Levels extension scaffold.

This module is intentionally isolated so future features can be added without
rewriting the core database, permission, logging or configuration layers.
"""
from discord.ext import commands

class Levels(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

async def setup(bot):
    await bot.add_cog(Levels(bot))
