import logging
import discord
from .embeds import info

log = logging.getLogger("jaduu")

async def send_log(guild, channel_id, title, description, color=None):
    if not channel_id:
        return
    channel = guild.get_channel(channel_id)
    if not isinstance(channel, discord.TextChannel):
        return
    embed = info(title, description)
    if color:
        embed.color = color
    try:
        await channel.send(embed=embed)
    except discord.HTTPException:
        log.exception("Could not send log in guild %s", guild.id)
