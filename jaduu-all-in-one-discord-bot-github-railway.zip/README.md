# Jaduu — All-in-One Discord Security & Community Bot

Production-oriented `discord.py 2.x` foundation for a large all-in-one Discord bot.

## Core implemented
- SQLite persistence with migration-friendly schema
- `/config` dashboard with embed, select menu, buttons and modal
- Moderation: ban, unban, softban, kick, timeout, untimeout, warn, warnings, clearwarnings, purge, slowmode, lock, unlock, hide, unhide
- Case IDs and moderation logs
- AntiNuke threshold engine, whitelist and role stripping
- Raid mode and new-account protection
- AutoMod for words, invites, mentions, caps and spam
- Configurable logging infrastructure
- Join-to-create voice rooms with rename/limit/lock/unlock
- Verification, welcome/goodbye and autorole infrastructure
- Custom commands storage
- Centralized error handling
- Railway/GitHub deployment files

## Discord Developer Portal
Enable:
- Server Members Intent
- Message Content Intent
- Presence Intent if you later add presence features

Give the bot only the permissions it needs. Put its role above roles it must manage.

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -m bot
```

## Railway
1. Push this repository to GitHub.
2. Create a Railway project from the repo.
3. Add `DISCORD_TOKEN` and `BOT_OWNER_ID`.
4. Deploy.
5. For SQLite persistence, attach a Railway volume and mount it at `/app/data`.

## Security
The token is never stored in source code or logged. The bot never attempts to bypass Discord role hierarchy. AntiNuke is best-effort because Discord only exposes audit information and actions allowed by the API.

## 800+ roadmap
This repository intentionally does not create hundreds of fake commands. The core is modular: add a new cog, reuse the database/check/log/permission utilities, and register it in `EXTENSIONS`. The schema and service boundaries are designed for a much larger feature set and future PostgreSQL migration.
