\
import json
import discord
from discord import app_commands
from discord.ext import commands
from ..core.checks import admin
from ..core.embeds import info, ok

class WordModal(discord.ui.Modal, title="Add AutoMod Word"):
    word = discord.ui.TextInput(label="Blocked word", max_length=100)

    def __init__(self, cog):
        super().__init__()
        self.cog = cog

    async def on_submit(self, interaction):
        cfg = await self.cog.bot.db.guild(interaction.guild.id)
        words = json.loads(cfg["automod_words"] or "[]")
        if self.word.value.lower() not in [x.lower() for x in words]:
            words.append(self.word.value)
        await self.cog.bot.db.set_guild(interaction.guild.id, automod_words=json.dumps(words))
        await interaction.response.send_message(embed=ok("AutoMod", f"Added `{self.word.value}`."), ephemeral=True)

class ConfigSelect(discord.ui.Select):
    def __init__(self, cog):
        self.cog = cog
        super().__init__(
            placeholder="Choose a configuration category…",
            options=[
                discord.SelectOption(label="Security", emoji="🛡️", value="security"),
                discord.SelectOption(label="Moderation", emoji="🔨", value="moderation"),
                discord.SelectOption(label="AutoMod", emoji="🤖", value="automod"),
                discord.SelectOption(label="Logs", emoji="📜", value="logs"),
                discord.SelectOption(label="Welcome", emoji="👋", value="welcome"),
                discord.SelectOption(label="Roles", emoji="🎭", value="roles"),
                discord.SelectOption(label="Voice", emoji="🔊", value="voice"),
                discord.SelectOption(label="Verification", emoji="🔐", value="verification"),
                discord.SelectOption(label="Commands", emoji="⚙️", value="commands"),
            ],
        )

    async def callback(self, interaction):
        await self.cog.category(interaction, self.values[0])

class ConfigView(discord.ui.View):
    def __init__(self, cog):
        super().__init__(timeout=180)
        self.add_item(ConfigSelect(cog))

class Config(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="config", description="Open the server configuration dashboard.")
    @admin()
    async def config(self, interaction):
        cfg = await self.bot.db.guild(interaction.guild.id)
        e = info(
            "⚙️ Server Configuration",
            "Use the select menu to navigate. Settings are stored persistently in SQLite."
        )
        e.add_field(name="🛡️ AntiNuke", value="ON" if cfg["antinuke_enabled"] else "OFF")
        e.add_field(name="🤖 AutoMod", value="ON" if cfg["automod_enabled"] else "OFF")
        e.add_field(name="🚨 Raid Mode", value="ON" if cfg["raid_mode"] else "OFF")
        await interaction.response.send_message(embed=e, view=ConfigView(self), ephemeral=True)

    async def category(self, interaction, name):
        cfg = await self.bot.db.guild(interaction.guild.id)

        if name == "security":
            e = info(
                "🛡️ Security",
                f"AntiNuke: **{'ON' if cfg['antinuke_enabled'] else 'OFF'}**\n"
                f"Threshold: **{cfg['antinuke_threshold']} actions / {cfg['antinuke_window']}s**\n"
                f"Raid Mode: **{'ON' if cfg['raid_mode'] else 'OFF'}**"
            )
            view = discord.ui.View(timeout=180)
            a = discord.ui.Button(label="Toggle AntiNuke", style=discord.ButtonStyle.danger)
            r = discord.ui.Button(label="Toggle Raid Mode", style=discord.ButtonStyle.danger)

            async def toggle_a(i):
                c = await self.bot.db.guild(i.guild.id)
                await self.bot.db.set_guild(i.guild.id, antinuke_enabled=0 if c["antinuke_enabled"] else 1)
                await i.response.send_message("AntiNuke toggled.", ephemeral=True)

            async def toggle_r(i):
                c = await self.bot.db.guild(i.guild.id)
                await self.bot.db.set_guild(i.guild.id, raid_mode=0 if c["raid_mode"] else 1)
                await i.response.send_message("Raid mode toggled.", ephemeral=True)

            a.callback = toggle_a
            r.callback = toggle_r
            view.add_item(a); view.add_item(r)
            await interaction.response.edit_message(embed=e, view=view)
            return

        if name == "automod":
            words = json.loads(cfg["automod_words"] or "[]")
            e = info("🤖 AutoMod", f"Enabled: **{'YES' if cfg['automod_enabled'] else 'NO'}**\nBlocked words: **{len(words)}**")
            view = discord.ui.View(timeout=180)
            t = discord.ui.Button(label="Toggle AutoMod", style=discord.ButtonStyle.primary)
            w = discord.ui.Button(label="Add blocked word", style=discord.ButtonStyle.secondary)

            async def toggle(i):
                c = await self.bot.db.guild(i.guild.id)
                await self.bot.db.set_guild(i.guild.id, automod_enabled=0 if c["automod_enabled"] else 1)
                await i.response.send_message("AutoMod toggled.", ephemeral=True)

            async def add(i):
                await i.response.send_modal(WordModal(self))

            t.callback = toggle
            w.callback = add
            view.add_item(t); view.add_item(w)
            await interaction.response.edit_message(embed=e, view=view)
            return

        await interaction.response.edit_message(
            embed=info(name.title(), "This module is scaffolded and ready for its dedicated configuration panel."),
            view=ConfigView(self)
        )

    @app_commands.command(name="config-antinuke-whitelist", description="Whitelist a user from AntiNuke.")
    @admin()
    async def whitelist(self, interaction, member: discord.Member):
        await self.bot.db.execute(
            "INSERT OR REPLACE INTO whitelist(guild_id,subject_id,subject_type) VALUES(?,?,?)",
            (interaction.guild.id, member.id, "user")
        )
        await interaction.response.send_message(embed=ok("Whitelist", f"{member.mention} is trusted by AntiNuke."), ephemeral=True)

async def setup(bot):
    await bot.add_cog(Config(bot))
