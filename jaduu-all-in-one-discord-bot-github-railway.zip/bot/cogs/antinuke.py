\
from collections import defaultdict, deque
from time import monotonic
import discord
from discord.ext import commands

class AntiNuke(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.events = defaultdict(lambda: defaultdict(deque))

    async def trusted(self, guild, user_id):
        if user_id in {guild.owner_id, self.bot.owner_id}:
            return True
        row = await self.bot.db.fetchone(
            "SELECT 1 FROM whitelist WHERE guild_id=? AND subject_id=? AND subject_type='user'",
            (guild.id, user_id)
        )
        return bool(row)

    async def hit(self, guild, actor, event):
        cfg = await self.bot.db.guild(guild.id)
        if not cfg["antinuke_enabled"] or await self.trusted(guild, actor.id):
            return
        now = monotonic()
        q = self.events[guild.id][event]
        q.append(now)
        while q and now - q[0] > cfg["antinuke_window"]:
            q.popleft()
        if len(q) < cfg["antinuke_threshold"]:
            return

        member = guild.get_member(actor.id)
        if member:
            for role in list(member.roles):
                if role.is_assignable() and (
                    role.permissions.administrator
                    or role.permissions.manage_guild
                    or role.permissions.manage_channels
                    or role.permissions.manage_roles
                ):
                    try:
                        await member.remove_roles(role, reason=f"AntiNuke: {event} threshold")
                    except discord.HTTPException:
                        pass
        await self.bot.security_log(
            guild,
            f"AntiNuke triggered by {actor.mention} for **{event}**. Dangerous roles were stripped where possible."
        )

    async def audit(self, guild, action, event):
        try:
            async for entry in guild.audit_logs(limit=1, action=action):
                await self.hit(guild, entry.user, event)
        except discord.HTTPException:
            pass

    @commands.Cog.listener()
    async def on_member_join(self, member):
        cfg = await self.bot.db.guild(member.guild.id)
        if cfg["raid_mode"] and cfg["automod_account_age"]:
            age_days = (discord.utils.utcnow() - member.created_at).days
            if age_days < cfg["automod_account_age"]:
                try:
                    await member.kick(reason="Raid mode: account too new")
                except discord.HTTPException:
                    pass

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        await self.audit(channel.guild, discord.AuditLogAction.channel_delete, "channel_delete")

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        await self.audit(role.guild, discord.AuditLogAction.role_delete, "role_delete")

async def setup(bot):
    await bot.add_cog(AntiNuke(bot))
