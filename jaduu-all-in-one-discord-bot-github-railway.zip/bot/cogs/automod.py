\
from collections import defaultdict, deque
from time import monotonic
import re
import json
import discord
from discord.ext import commands

INVITE_RE = re.compile(r"(discord\.gg/|discord\.com/invite/)", re.I)

class AutoMod(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.messages = defaultdict(lambda: defaultdict(deque))

    @commands.Cog.listener()
    async def on_message(self, message):
        if not message.guild or message.author.bot:
            return
        cfg = await self.bot.db.guild(message.guild.id)
        if not cfg["automod_enabled"]:
            return

        words = json.loads(cfg["automod_words"] or "[]")
        content = message.content
        lower = content.lower()
        reason = None

        if any(w.lower() in lower for w in words):
            reason = "blocked word"
        elif cfg["automod_invites"] and INVITE_RE.search(content):
            reason = "Discord invite"
        elif content.count("@") >= cfg["automod_mentions"]:
            reason = "excessive mentions"
        elif len(content) >= 12:
            letters = sum(c.isalpha() for c in content)
            if letters and (sum(c.isupper() for c in content) / letters * 100) >= cfg["automod_caps"]:
                reason = "caps spam"

        q = self.messages[message.guild.id][message.author.id]
        now = monotonic()
        q.append(now)
        while q and now - q[0] > cfg["automod_spam_window"]:
            q.popleft()
        if len(q) >= cfg["automod_spam_count"]:
            reason = reason or "spam/flood"

        if reason:
            try:
                await message.delete()
            except discord.HTTPException:
                pass
            await self.bot.security_log(
                message.guild,
                f"AutoMod blocked {message.author.mention}: **{reason}** in {message.channel.mention}"
            )

async def setup(bot):
    await bot.add_cog(AutoMod(bot))
